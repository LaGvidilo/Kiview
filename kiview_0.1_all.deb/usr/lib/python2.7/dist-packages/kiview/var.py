lst=[]
current=""
sup=[]
curs=0
curwidget=[]
tmpcur=0
